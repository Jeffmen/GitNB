ALTER TABLE cards ADD COLUMN delayUnit TEXT;

ALTER TABLE cards ADD COLUMN delayTime INTEGER;

UPDATE cards SET delayUnit = "NOW", delayTime = 0;