ALTER TABLE cards ADD COLUMN countryCode TEXT;

UPDATE cards set countryCode = "xx";