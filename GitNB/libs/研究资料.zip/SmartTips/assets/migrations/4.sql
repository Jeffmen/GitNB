ALTER TABLE cards ADD COLUMN defaultPosition INTEGER;
